# JUNÇÃO RECOMENDADA:

# 🔧 3️⃣ Rooms + Reviews + Hosts (Completo)

SELECT 
    r.id AS room_id,
    r.name AS room_name,
    r.neighbourhood,
    r.neighbourhood_group,
    r.latitude,
    r.longitude,
    r.room_type,
    r.minimum_nights,
    rv.price,
    rv.number_of_reviews,
    rv.last_review,
    rv.reviews_per_month,
    rv.calculated_host_listings_count,
    rv.availability_365,
    h.host_id,
    h.host_name
FROM `rota-airbnb-465302.dataset_airbnb.rooms_tratada` r
LEFT JOIN `rota-airbnb-465302.dataset_airbnb.reviews_tratada` rv
ON r.id = rv.id
LEFT JOIN `rota-airbnb-465302.dataset_airbnb.hosts_deduplicado` h
ON r.id = h.host_id;

----------------------------------------------------------------------------
CREATE OR REPLACE TABLE `rota-airbnb-465302.dataset_airbnb.base_final` AS
SELECT 
    r.id AS room_id,
    r.name AS room_name,
    r.neighbourhood,
    r.neighbourhood_group,
    r.latitude,
    r.longitude,
    r.room_type,
    r.minimum_nights,
    rv.price,
    rv.number_of_reviews,
    rv.last_review,
    rv.reviews_per_month,
    rv.calculated_host_listings_count,
    rv.availability_365,
    h.host_id,
    h.host_name
FROM `rota-airbnb-465302.dataset_airbnb.rooms_tratada` r
LEFT JOIN `rota-airbnb-465302.dataset_airbnb.reviews_tratada` rv
ON r.id = rv.id
LEFT JOIN `rota-airbnb-465302.dataset_airbnb.hosts_deduplicado` h
ON r.id = h.host_id;

----------------------------------------------------------------
# CORREÇÃO:







CREATE OR REPLACE TABLE `rota-airbnb-465302.dataset_airbnb.base_final` AS
SELECT 
    id,
    name,
    neighbourhood,
    neighbourhood_group,
    latitude,
    CAST(longitude AS FLOAT64) AS longitude,
    room_type,
    minimum_nights
FROM `rota-airbnb-465302.dataset_airbnb.rooms_tratada`;


