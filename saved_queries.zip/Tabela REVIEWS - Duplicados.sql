#identificando os duplicados

SELECT
  id,
  COUNT(*) AS ocorrencias
FROM
  `rota-airbnb-465302.dataset_airbnb.reviews`
GROUP BY id
HAVING COUNT(*) > 1;

# excluir os registros com id inválido
CREATE OR REPLACE TABLE `rota-airbnb-465302.dataset_airbnb.reviews_corrigida` AS
SELECT *
FROM `rota-airbnb-465302.dataset_airbnb.reviews`
WHERE id NOT IN (
  'NEAR TO YANKE STADIUM"',
  'muy cercadetodo"',
  '15 min F Times Square"',
  'Se habla Español"',
  'Mount Sinai"',
  'Brownstone"',
  'AFFORDABLE PRICE"'
);

# (Opcional) Verifique se agora os ids ficaram únicos:
SELECT id, COUNT(*) AS ocorrencias
FROM `rota-airbnb-465302.dataset_airbnb.reviews_corrigida`
GROUP BY id
HAVING COUNT(*) > 1;

