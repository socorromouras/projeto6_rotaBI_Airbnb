SELECT
  COUNTIF(id IS NULL) AS nulo_id,
  COUNTIF(host_id IS NULL) AS nulo_host_id,
  COUNTIF(price IS NULL) AS nulo_price,
  COUNTIF(number_of_reviews IS NULL) AS nulo_number_of_reviews,
  COUNTIF(last_review IS NULL) AS nulo_last_review,
  COUNTIF(reviews_per_month IS NULL) AS nulo_reviews_per_month,
  COUNTIF(calculated_host_listings_count IS NULL) AS nulo_host_listings_count,
  COUNTIF(availability_365 IS NULL) AS nulo_availability_365
FROM
  `rota-airbnb-465302.dataset_airbnb.reviews`;


  #  Verifique valores não numéricos em number_of_reviews:
  SELECT DISTINCT number_of_reviews
FROM `rota-airbnb-465302.dataset_airbnb.reviews`
WHERE SAFE_CAST(number_of_reviews AS INT64) IS NULL
  AND number_of_reviews IS NOT NULL;


# TRATAMENTO PARA OS NULOS
-- Criar uma nova tabela (ou uma visualização) com registros limpos, onde:
-- number_of_reviews é um número válido
-- Campos como availability_365 e number_of_reviews são convertidos corretamente
-- Nulos opcionais continuam (como last_review, que pode ser legítimo)

CREATE OR REPLACE TABLE `rota-airbnb-465302.dataset_airbnb.reviews_tratada` AS
SELECT
  id,
  host_id,
  price,
  CAST(number_of_reviews AS INT64) AS number_of_reviews,
  last_review,
  reviews_per_month,
  calculated_host_listings_count,
  IFNULL(availability_365, 0) AS availability_365
FROM
  `rota-airbnb-465302.dataset_airbnb.reviews`
WHERE SAFE_CAST(number_of_reviews AS INT64) IS NOT NULL;

