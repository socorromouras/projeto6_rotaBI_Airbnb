# 📈 ETAPA 4 — Verificar DISCREPANTES / OUTLIERS

SELECT
  MIN(minimum_nights) AS min_noites,
  MAX(minimum_nights) AS max_noites,
  MIN(latitude) AS lat_min,
  MAX(latitude) AS lat_max,
  MIN(CAST(longitude AS FLOAT64)) AS long_min,
  MAX(CAST(longitude AS FLOAT64)) AS long_max
FROM `rota-airbnb-465302.dataset_airbnb.rooms`
WHERE SAFE_CAST(longitude AS FLOAT64) IS NOT NULL;
