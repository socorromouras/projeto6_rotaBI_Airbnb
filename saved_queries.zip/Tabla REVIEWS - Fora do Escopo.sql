# VALORES FORA DO ESCOPO

#➤ availability_365 (deve estar entre 0 e 365):
SELECT *
FROM `rota-airbnb-465302.dataset_airbnb.reviews`
WHERE availability_365 < 0 OR availability_365 > 365;

# ➤ price (valores negativos ou absurdamente altos)
-- Você pode considerar outliers se price < 0 ou price > 10000 (ou outro limite que julgar razoável):
SELECT *
FROM `rota-airbnb-465302.dataset_airbnb.reviews`
WHERE price < 0 OR price > 10000;

#➤ reviews_per_month (valores negativos não fazem sentido)
SELECT *
FROM `rota-airbnb-465302.dataset_airbnb.reviews`
WHERE reviews_per_month < 0;
