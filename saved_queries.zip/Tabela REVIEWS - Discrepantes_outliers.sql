# Discrepantes/outliers (visão geral)
SELECT
  MIN(price) AS preco_min,
  MAX(price) AS preco_max,
  MIN(reviews_per_month) AS rev_mes_min,
  MAX(reviews_per_month) AS rev_mes_max,
  MIN(availability_365) AS disponibilidade_min,
  MAX(availability_365) AS disponibilidade_max
FROM
  `rota-airbnb-465302.dataset_airbnb.reviews`;

# TRATAMENTO
-- Verificar quantos imóveis têm preços (PRICES) extremos:
SELECT
  COUNT(*) AS total_registros,
  COUNTIF(price = 0) AS preco_zero,
  COUNTIF(price > 1000) AS acima_1000,
  COUNTIF(price > 5000) AS acima_5000,
  COUNTIF(price = 10000) AS igual_10000
FROM
  `rota-airbnb-465302.dataset_airbnb.reviews_corrigida`;

-- Verificar a distribuição:(reviews_per_month)
SELECT
  COUNT(*) AS total,
  COUNTIF(reviews_per_month > 20) AS acima_20,
  COUNTIF(reviews_per_month > 30) AS acima_30,
  COUNTIF(reviews_per_month > 40) AS acima_40
FROM
  `rota-airbnb-465302.dataset_airbnb.reviews_corrigida`;

# TRATAMENTO:
-- Query para criar flag de outlier:
CREATE OR REPLACE TABLE `rota-airbnb-465302.dataset_airbnb.reviews_com_outlier_flag` AS
SELECT
  *,
  CASE 
    WHEN price = 0 THEN 'preco_zero'
    WHEN price > 5000 THEN 'preco_extremo'
    WHEN reviews_per_month > 30 THEN 'review_extremo'
    ELSE 'normal'
  END AS tipo_outlier
FROM `rota-airbnb-465302.dataset_airbnb.reviews_corrigida`;





