# 🚫 ETAPA 3 — Verificar VALORES FORA DO ESCOPO

-- ➤ 1. room_type (deve ser um dos tipos válidos)

SELECT DISTINCT room_type
FROM `rota-airbnb-465302.dataset_airbnb.rooms`;

-- ➤ 2. minimum_nights (valores muito altos ou 0 são suspeitos)

SELECT *
FROM `rota-airbnb-465302.dataset_airbnb.rooms`
WHERE minimum_nights <= 0 OR minimum_nights > 365;

---------------------------------------------------------------------
#TRATAIVA:

#🚨 Query para excluir registros inválidos de room_type:

CREATE OR REPLACE TABLE `rota-airbnb-465302.dataset_airbnb.rooms_corrigida` AS
SELECT *
FROM `rota-airbnb-465302.dataset_airbnb.rooms`
WHERE room_type IN ('Private room', 'Entire home/apt', 'Shared room');

# Verificar depois da limpeza:
SELECT DISTINCT room_type
FROM `rota-airbnb-465302.dataset_airbnb.rooms_corrigida`;

###################################################################################

# ✅ Query para entender a distribuição de minimum_nights após exclusões:

# 1️⃣ Verificar os extremos:
SELECT 
  MIN(minimum_nights) AS min_nights,
  MAX(minimum_nights) AS max_nights,
  APPROX_QUANTILES(minimum_nights, 4) AS quartis
FROM `rota-airbnb-465302.dataset_airbnb.rooms_corrigida`;

----------------------------------------------------------------------------
# 2️⃣ Contar registros por faixas para ver onde estão concentrados
SELECT 
  COUNTIF(minimum_nights <= 7) AS ate_7_noites,
  COUNTIF(minimum_nights BETWEEN 8 AND 30) AS de_8_a_30,
  COUNTIF(minimum_nights BETWEEN 31 AND 90) AS de_31_a_90,
  COUNTIF(minimum_nights BETWEEN 91 AND 365) AS de_91_a_365,
  COUNTIF(minimum_nights > 365) AS acima_365
FROM `rota-airbnb-465302.dataset_airbnb.rooms_corrigida`;

-----------------------------------------------------------------------------

# 🚨 Query para limpar os outliers finais:

CREATE OR REPLACE TABLE `rota-airbnb-465302.dataset_airbnb.rooms_tratada` AS
SELECT *
FROM `rota-airbnb-465302.dataset_airbnb.rooms_corrigida`
WHERE minimum_nights > 0 AND minimum_nights <= 365;


