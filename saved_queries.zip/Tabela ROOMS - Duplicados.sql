# 🔁 ETAPA 2 — Verificar DUPLICADOS por id

SELECT
  id,
  COUNT(*) AS ocorrencias
FROM
  `rota-airbnb-465302.dataset_airbnb.rooms`
GROUP BY id
HAVING COUNT(*) > 1;

-----------------------------------------------------------------------------
# 🚨 Query para excluir esses registros inválidos:

CREATE OR REPLACE TABLE `rota-airbnb-465302.dataset_airbnb.rooms_corrigida` AS
SELECT *
FROM `rota-airbnb-465302.dataset_airbnb.rooms`
WHERE id NOT IN (
  'Brownstone"',
  'AFFORDABLE PRICE"',
  'Mount Sinai"',
  'NEAR TO YANKE STADIUM"',
  '15 min F Times Square"',
  'muy cercadetodo"',
  'Se habla Español"'
);

-------------------------------------------------------------------------------
# APENAS PARA VALIDAR A AÇÃO:

SELECT id, COUNT(*) AS ocorrencias
FROM `rota-airbnb-465302.dataset_airbnb.rooms_corrigida`
GROUP BY id
HAVING COUNT(*) > 1;