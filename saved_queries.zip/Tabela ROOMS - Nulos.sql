# ✅ ETAPA 1 — Verificar VALORES NULOS
SELECT
  COUNTIF(id IS NULL) AS nulo_id,
  COUNTIF(name IS NULL) AS nulo_name,
  COUNTIF(neighbourhood IS NULL) AS nulo_neighbourhood,
  COUNTIF(neighbourhood_group IS NULL) AS nulo_neighbourhood_group,
  COUNTIF(latitude IS NULL) AS nulo_latitude,
  COUNTIF(longitude IS NULL) AS nulo_longitude,
  COUNTIF(room_type IS NULL) AS nulo_room_type,
  COUNTIF(minimum_nights IS NULL) AS nulo_minimum_nights
FROM
  `rota-airbnb-465302.dataset_airbnb.rooms`;

