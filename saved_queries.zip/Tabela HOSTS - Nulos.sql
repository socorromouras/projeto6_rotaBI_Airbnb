SELECT
  COUNTIF(host_id IS NULL) AS nulos_host_id,
  COUNTIF(host_name IS NULL) AS nulos_host_name
FROM
  `rota-airbnb-465302.dataset_airbnb.hosts`;
